-- Martin Escardo 2015

import System.IO

type Move = Int 

possibleMoves :: [Move]
possibleMoves = [0..8]

wins :: [Move] -> Bool
wins = someContained [[0,1,2],[3,4,5],[6,7,8], -- lines
                      [0,3,6],[1,4,7],[2,5,8], -- columns
                      [0,4,8],[2,4,6]]         -- diagonals

data Player = X | O deriving (Eq,Show)

type Outcome = Int -- We will use only -1, 0, 1.

data Board = Board {
                nextPlayer     :: Player
              , xmoves         :: [Move] 
              , omoves         :: [Move] 
              , allowedMoves   :: [Move]
              , outcome        :: Outcome
             }

initialBoard :: Board
initialBoard = Board X [] [] possibleMoves 0

play :: Move -> Board -> Board
play m (Board X xs os as 0) = let xs' = insert m xs in
  if wins xs' 
     then Board O xs' os []            1
     else Board O xs' os (delete m as) 0
play m (Board O xs os as 0) = let os' = insert m os in
  if wins os'
     then Board X xs os' []          (-1)
     else Board X xs os' (delete m as) 0
play m board = error "Bug when using function play."

winning :: Board -> Bool
winning board = outcome board /= 0

data Tree = Fork Board [(Move,Tree)]

treeOf :: Board -> Tree
treeOf board = Fork board forest
  where
    forest :: [(Move,Tree)]
    forest 
      | winning board = [] 
      | otherwise     = [(m, treeOf(play m board)) | m <- allowedMoves board]

optimalOutcome :: Tree -> Outcome
optimalOutcome (Fork board []) = outcome board 
optimalOutcome (Fork board forest) 
   | nextPlayer board == X = supremum optimalOutcomes
   | otherwise             = infimum  optimalOutcomes
 where 
   optimalOutcomes = [optimalOutcome tree | (_,tree) <- forest]

tictactoe :: Tree
tictactoe = treeOf initialBoard

optimalMoves :: Tree -> [(Move,Tree)]
optimalMoves (Fork board []) = []
optimalMoves (tree@(Fork _ forest)) =
  [(m,subtree) | (m,subtree) <- forest, 
                 optimalOutcome subtree == optimalOutcome tree]

-- We solved the game with the above code.
-- (That was 68 lines.)

-- We now do more mundane things.

instance Show Board where
  show (Board pl xs os as oc) =
       show pl ++ " plays next\n\n"
    ++ f 0 ++ " | " ++ f 1 ++ " | " ++ f 2 ++ "\n"
    ++ "--+---+--\n"
    ++ f 3 ++ " | " ++ f 4 ++ " | " ++ f 5 ++ "\n"
    ++ "--+---+--\n"
    ++ f 6 ++ " | " ++ f 7 ++ " | " ++ f 8 ++ "\n"
    where
      f m | m `elem` xs = show X
          | m `elem` os = show O
          | otherwise   = show m


-- We use the above to play interactively with a user:

usersTurn :: Tree -> IO()
usersTurn (Fork board []) = 
  putStrLn("Game over with outcome " ++ show(outcome board))
usersTurn (tree@(Fork board forest)) = do
  putStrLn(show board)
  putStrLn("The optimal outcome is " ++ show(optimalOutcome tree))
  putStr("Please play: ")
  hFlush stdout
  s <- getLine
  let m = read s :: Move
  case lookup m forest of
    Nothing -> do
      putStrLn "Invalid move. Try again."
      usersTurn (Fork board forest)
    Just tree -> do
      if winning board
         then putStrLn (show board ++ "\nYou win.")
         else computersTurn tree

chooseOneOf :: [a] -> a
chooseOneOf = head -- (For example.)

computersTurn :: Tree -> IO()
computersTurn (Fork board []) = 
  putStrLn("Game over with outcome " ++ show(outcome board))
computersTurn (tree@(Fork board forest)) = do
  putStrLn(show board)
  putStrLn("I am thinking...")
  putStrLn("The optimal outcome is " ++ show(optimalOutcome tree))
  let myMoves = optimalMoves tree
  putStrLn("My optimal moves are " ++ show [ m | (m,_) <- myMoves])
  -- putStrLn(show([ (m,outcomes'' tree) | (m,tree) <- forest]))
  if null myMoves
     then putStrLn "Draw."
     else do
       let (m,subtree) = chooseOneOf myMoves 
       putStrLn("I play " ++ show m)
       let Fork board' forest' = subtree
       if winning board' 
          then putStrLn(show board' ++ "\nI win.")
          else usersTurn subtree

-- Change this to choose who starts:

main :: IO()
main = computersTurn tictactoe

-- That's it. Now the general "library" functions that are not
-- particular to the above task:

supremum :: [Outcome] -> Outcome
supremum []        = -1 
supremum (1:xs)    =  1
supremum ((-1):xs) = supremum xs
supremum (0:xs)    = supremum0 xs
  where
    supremum0 []     = 0
    supremum0 (1:xs) = 1
    supremum0 (_:xs) = supremum0 xs

infimum :: [Outcome] -> Outcome
infimum []        =  1 
infimum (1:xs)    = infimum xs
infimum ((-1):xs) = -1
infimum (0:xs)    = infimum0 xs
  where
    infimum0 []        = 0
    infimum0 ((-1):xs) = -1
    infimum0 (_:xs)    = infimum0 xs

contained :: Ord x => [x] -> [x] -> Bool
contained [] ys = True
contained xs [] = False
contained (us@(x : xs)) (y : ys) 
    | x == y    = contained xs ys
    | x >= y    = contained us ys
    | otherwise = False

someContained :: Ord x => [[x]] -> [x] -> Bool
someContained [] ys = False
someContained xss [] = False
someContained (xs : xss) ys = contained xs ys || someContained xss ys

insert :: Ord x => x -> [x] -> [x]
insert x [] = [x]
insert x (vs@(y : ys)) 
    | x == y       = vs
    | x <  y       = x : vs
    | otherwise    = y : insert x ys

delete :: Ord x => x -> [x] -> [x]
delete x [] = []
delete x (vs@(y : ys))
    | x == y    = ys 
    | x <  y    = vs
    | otherwise = y : delete x ys 
