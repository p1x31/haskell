-- Martin Escardo, 9 October 2016.

-- There are applications behind this handout (predictive text, Morse
-- code, Huffman text compression, ...), but here I concentrate on the
-- ideas and techniques, rather than the applications. I have written
-- other handouts/programs for the applications.

-- Starting from the root of a tree, we can follow a path and get a
-- subtree. This can be done for a variety of kinds of trees. We
-- consider two kinds in this handout.

-- First kind of tree. Certain binary trees:

data BinTree a = Empty | Branch a (BinTree a) (BinTree a)
               deriving (Show,Eq)
{-

Example:
                     7
                    /
                 5 8   9
                /   \ / 
          t =  4     6
                \   /
                 \ /
                  3

In Haskell (rotate clockwise by 90 degrees):

-}

t :: BinTree Int
t = Branch 3 
       (Branch 4 
           Empty
           (Branch 5 Empty Empty)
       )
       (Branch 6 
           (Branch 8 
               Empty
               (Branch 7 Empty Empty)
           )
           (Branch 9 Empty Empty)
       )

-- Equivalent and less dreadable:
t' = Branch 3 (Branch 4 Empty (Branch 5 Empty Empty)) (Branch 6 (Branch 8 Empty (Branch 7 Empty Empty)) (Branch 9 Empty Empty))

claim0 :: Bool
claim0 = t == t' 

-- We count the number of nodes:
size :: BinTree a -> Int
size Empty = 0
size (Branch x l r) = 1 + size l + size r

claim1 :: Bool
claim1 = size t == 7

height :: BinTree a -> Int
height Empty = 0
height (Branch x l r) = 1 + max (height l) (height r)

claim2 :: Bool
claim2 = height t == 4

-- We now consider paths in a BinTree.

-- The directions are left and right, abbreviated as follows:
data Direction = L | R

-- A path in a BinTree is specified by a list of directions:
type Path = [Direction]

-- We want to follow a path in a tree to get a subtree: 

subtree :: BinTree a -> Path -> BinTree a
subtree Empty          []     = Empty
subtree Empty          (d:ds) = undefined
subtree (Branch x l r) []     = (Branch x l r) 
subtree (Branch x l r) (L:ds) = subtree l ds
subtree (Branch x l r) (R:ds) = subtree r ds

-- A different way to do the pattern matching:

subtree' :: BinTree a -> Path -> BinTree a
subtree' t              []     = Empty
subtree' (Branch x l r) (L:ds) = subtree' l ds
subtree' (Branch x l r) (R:ds) = subtree' r ds
subtree' _              _      = undefined

{-

 Examples: 

                     7
                    /
                 5 8   9
                /   \ / 
          t =  4     6
                \   /
                 \ /
                  3

  subtree t [L] = Branch 4 Empty (Branch 5 Empty Empty)
  subtree t [L,R] = Branch 5 Empty Empty
  subtree t [R,L] = Branch 8 Empty (Branch 7 Empty Empty)
  subtree t [R,R] = Branch 9 Empty Empty
  subtree t [R,R,R] = Empty
  subtree t [R,R,R,R] is undefined (there is no such subtree)
-}

 
-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

-- Second kind of tree. Certain trees that can branch any number of
-- times (we replace Branch by Fork for them). We also remove the
-- possibility of the empty tree.

data Tree a = Fork a [Tree a]

-- For example, Fork 17 [] :: Tree Int is a leaf.

tsize :: Tree a -> Int
tsize (Fork x ts) = 1 + sum [tsize t | t <- ts]

-- Think a bit about this (did we get the definition right?):
theight :: Tree a -> Int
theight (Fork x []) = 1
theight (Fork x ts) = 1 + maximum [theight t | t <- ts]

-- We now consider paths in a Tree.

-- The directions in Trees are non-negative integers.  A path in a
-- Tree is specified by a list of such directions:
type TPath = [Int]

-- We want to follow a path in a tree to get a subtree: 

tsubtree :: Tree a -> TPath -> Tree a
tsubtree (Fork x ts)  []    = Fork x ts
tsubtree (Fork x ts) (d:ds) = tsubtree (ts !! d) ds


